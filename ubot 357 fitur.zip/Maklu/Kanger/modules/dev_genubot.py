from Kanger import *


@PY.CALLBACK("bahan")
async def _(client, callback_query):
    await need_api(client, callback_query)

@PY.CALLBACK("bayar_dulu")
async def _(client, callback_query):
    await payment_userbot(client, callback_query)

@PY.CALLBACK("add_ubot")
async def _(client, callback_query):
    await bikin_ubot(client, callback_query)

@PY.CALLBACK("cek_ubot")
@PY.BOT("kanger", FILTERS.OWNER)
async def _(client, message):
    await cek_ubot(client, message)

@PY.CALLBACK("cek_masa_aktif")
async def _(client, callback_query):
    await cek_userbot_expired(client, callback_query)

@PY.CALLBACK("del_ubot")
async def _(client, callback_query):
    await hapus_ubot(client, callback_query)

@PY.CALLBACK("^(prev_ub|next_ub)")
async def _(client, callback_query):
    await next_prev_ubot(client, callback_query)

@PY.CALLBACK("tuku_prem")
async def _(client, callback_query):
    await buy_prem(client, callback_query)
