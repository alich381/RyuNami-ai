#==================================#
#Hijacked by anonymous
#==================================#

DEVS = [7300602830]

DEVICE_MODEL = "Kanger Assistant"

API_ID = 2040

API_HASH = "b18441a1ff607e10a989891a5462e627"

BOT_TOKEN = "8355476706:AAG-kWPJQ5HgKRhMuid06IRSBcxIrH48soM"

OWNER_ID = 7300602830

DUMP_LOGS = -1001912692470

USER_ID = 7300602830

LOGS_MAKER_UBOT = -1001905144356

SUPPORT_GROUP = -1001906038831

BLACKLIST_CHAT = [
    -1001473548283,-1001853283409,-1001704645461
    ]

RMBG_API = "3hYYMrCnpDQmAmE81u9aQAz2"

COMMAND = ". ! ? : ;"
PREFIX = COMMAND.split()

MONGO_URL = "mongodb+srv://reon:reon@cluster0.h52cpph.mongodb.net/?retryWrites=true&w=majority"