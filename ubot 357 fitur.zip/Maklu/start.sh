git pull
python3 -m Kanger